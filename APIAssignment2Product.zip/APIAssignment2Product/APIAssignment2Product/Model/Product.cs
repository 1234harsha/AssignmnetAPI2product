﻿namespace APIAssignment2Product.Model
{
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public float Price { get; set; }
        public float Stock { get; set; }
    }
}
