﻿using APIAssignment2Product.Model;

namespace APIAssignment2Product.Repository
{
    public interface IOrderRepository
    {
    
            string OrderProduct(Order order);
            List<Order> GetOrders();
            void DeleteOrder(int id);

        
    }
}
