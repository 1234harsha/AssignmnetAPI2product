﻿using APIAssignment2Product.Model;

namespace APIAssignment2Product.Repository
{
    public interface IProductRepository
    {
        void AddProduct(Product product);
        string UpdateProduct(Product product);
        string DeleteProduct(int id);

        Product GetProductByIdorName(int? productId, string? productName);

        List<Product> GetProductByCategory(string Category);
    }
}
